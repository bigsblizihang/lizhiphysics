import codecs
import os
from setuptools.command.upload import upload as _upload

from setuptools import find_packages, setup

class upload(_upload):
    def run(self):
        # 打开.pypirc文件并读取PYPI账号信息
        with open('~/.pypirc') as f:
            config = configparser.ConfigParser()
            config.read_file(f)
            username = config.get('pypi', 'username')
            password = config.get('pypi', 'password')

        # 设置上传账号信息
        self.username = username
        self.password = password

        # 调用默认的上传操作
        _upload.run(self)

# these things are needed for the README.md show on pypi
here = os.path.abspath(os.path.dirname(__file__))

with codecs.open(os.path.join(here, "lizhiphysics.md"), encoding="utf-8") as fh:
    long_description = "\n" + fh.read()


VERSION = '0.0.1'
DESCRIPTION = 'A light weight command line menu that supports Windows, MacOS, and Linux'
LONG_DESCRIPTION = 'A light weight command line menu. Supporting Windows, MacOS, and Linux. It has support for hotkeys'

# Setting up
setup(
    name="lizhiphysics",
    version=VERSION,
    author="clever chen",
    author_email="",
    description=DESCRIPTION,
    long_description_content_type="text/markdown",
    long_description=long_description,
    packages=find_packages(),
    install_requires=[
        'getch; platform_system=="Unix"',
        'getch; platform_system=="MacOS"',
    ],
    keywords=['python', 'physics', 'lizhi', 'windows', 'mac', 'linux'],
    classifiers=[
        "Development Status :: 1 - Planning",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Operating System :: Unix",
        "Operating System :: MacOS :: MacOS X",
        "Operating System :: Microsoft :: Windows",
    ]
)
